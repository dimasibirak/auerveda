-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 24 2017 г., 15:59
-- Версия сервера: 5.7.19-17-beget-5.7.19-17-1-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `x9168742_sor`
--

-- --------------------------------------------------------

--
-- Структура таблицы `format_kurs`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 10 2017 г., 21:00
-- Последняя проверка: Дек 10 2017 г., 21:00
--

DROP TABLE IF EXISTS `format_kurs`;
CREATE TABLE `format_kurs` (
  `id` int(15) NOT NULL,
  `id_kurs` int(15) NOT NULL,
  `img` varchar(500) NOT NULL,
  `zag` varchar(500) NOT NULL,
  `text` varchar(1000) NOT NULL,
  `pos` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `icons_kurs`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 10 2017 г., 21:00
-- Последняя проверка: Дек 10 2017 г., 21:00
--

DROP TABLE IF EXISTS `icons_kurs`;
CREATE TABLE `icons_kurs` (
  `id` int(15) NOT NULL,
  `id_kurs` int(15) NOT NULL,
  `img` varchar(500) NOT NULL,
  `zag` varchar(500) NOT NULL,
  `text` varchar(1000) NOT NULL,
  `pos` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `kurs`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 11 2017 г., 21:40
--

DROP TABLE IF EXISTS `kurs`;
CREATE TABLE `kurs` (
  `id` int(15) NOT NULL,
  `title` varchar(700) NOT NULL,
  `desc` varchar(700) NOT NULL,
  `keys` varchar(700) NOT NULL,
  `pu` varchar(100) NOT NULL,
  `name_kurs` varchar(500) NOT NULL,
  `pod_name_kurs` varchar(500) NOT NULL,
  `price` int(15) NOT NULL,
  `ind_price` int(15) NOT NULL,
  `header_img` varchar(500) NOT NULL,
  `kurs_img` varchar(1000) NOT NULL,
  `hours` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `text_kurs` text NOT NULL,
  `teachers` varchar(100) NOT NULL,
  `docs` varchar(500) NOT NULL,
  `bag_opz` int(15) NOT NULL,
  `href_opz` varchar(500) NOT NULL,
  `kind_kurs` int(15) NOT NULL,
  `tel` varchar(300) NOT NULL,
  `email` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `kurs`
--

INSERT INTO `kurs` (`id`, `title`, `desc`, `keys`, `pu`, `name_kurs`, `pod_name_kurs`, `price`, `ind_price`, `header_img`, `kurs_img`, `hours`, `days`, `text_kurs`, `teachers`, `docs`, `bag_opz`, `href_opz`, `kind_kurs`, `tel`, `email`) VALUES
(2, '213', '', '', '234', '2134', '1243', 0, 0, '820sunlight-166733_1920.jpg', '', 0, 0, '', '', '6;5;', 1, '', 1, '', ''),
(3, '12', '', '', '33333', '333333', '', 0, 0, '', '', 0, 0, '', '3;1;', '5;6;', 0, '', 1, '', ''),
(4, 'Title страницы', 'Description страницы', 'Keywords страницы', 'alias', 'Название курса', 'Подзаголовок', 1000, 2000, '280photo3.jpg', '', 20, 5, '<p>Описание курса</p>\r\n', '3;', '', 1, 'qwe', 1, 'Телефон', 'Email');

-- --------------------------------------------------------

--
-- Структура таблицы `kurs_module`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 10 2017 г., 21:00
-- Последняя проверка: Дек 10 2017 г., 21:00
--

DROP TABLE IF EXISTS `kurs_module`;
CREATE TABLE `kurs_module` (
  `id` int(15) NOT NULL,
  `id_kurs` int(15) NOT NULL,
  `name_module` varchar(500) NOT NULL,
  `text_module` text NOT NULL,
  `kratko_module` varchar(500) NOT NULL,
  `start_date_module` date NOT NULL,
  `finish_date_module` int(11) NOT NULL,
  `start_hours_module` varchar(50) NOT NULL,
  `finish_hours_module` varchar(50) NOT NULL,
  `parent` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `kurs_rasp`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 10 2017 г., 21:00
--

DROP TABLE IF EXISTS `kurs_rasp`;
CREATE TABLE `kurs_rasp` (
  `id` int(15) NOT NULL,
  `id_kurs` int(15) NOT NULL,
  `date_begin` datetime NOT NULL,
  `date_finish` datetime NOT NULL,
  `date_finish_zap` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--
-- Создание: Дек 10 2017 г., 21:00
-- Последнее обновление: Дек 10 2017 г., 21:17
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` int(15) NOT NULL,
  `fio` varchar(500) NOT NULL,
  `img` varchar(500) NOT NULL,
  `text` text NOT NULL,
  `id_kurs` int(15) NOT NULL,
  `start_act` datetime NOT NULL,
  `finish_act` datetime NOT NULL,
  `new_price` int(11) NOT NULL,
  `type` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`id`, `fio`, `img`, `text`, `id_kurs`, `start_act`, `finish_act`, `new_price`, `type`) VALUES
(3, 'dsddsd', '3560avatar5.png', '<p>ddd</p>\r\n', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 1),
(5, '123', '8960photo1.png', '<p>2134</p>\r\n', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 2),
(6, '2314', '5427user3-128x128.jpg', '<p>433444</p>\r\n', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `format_kurs`
--
ALTER TABLE `format_kurs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kurs` (`id_kurs`,`pos`);

--
-- Индексы таблицы `icons_kurs`
--
ALTER TABLE `icons_kurs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kurs` (`id_kurs`),
  ADD KEY `pos` (`pos`);

--
-- Индексы таблицы `kurs`
--
ALTER TABLE `kurs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `kurs_module`
--
ALTER TABLE `kurs_module`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_kurs` (`id_kurs`,`parent`);

--
-- Индексы таблицы `kurs_rasp`
--
ALTER TABLE `kurs_rasp`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `format_kurs`
--
ALTER TABLE `format_kurs`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `icons_kurs`
--
ALTER TABLE `icons_kurs`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kurs`
--
ALTER TABLE `kurs`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `kurs_module`
--
ALTER TABLE `kurs_module`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `kurs_rasp`
--
ALTER TABLE `kurs_rasp`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
